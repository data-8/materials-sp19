test = {
  'name': 'q3_2_3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(0)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(1)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(3)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(4)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(5)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(6)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(7)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(8)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(9)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> check(10)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
