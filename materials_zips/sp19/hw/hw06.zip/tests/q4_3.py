test = {
  'name': 'Question 4_3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # It looks like your function doesn't return anything!
          >>> maximum_magnitude() is None
          False
          >>> # The simulated maximum can't be bigger than the actual maximum!
          >>> maximum_magnitude() <= max(earthquakes.column('mag'))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
