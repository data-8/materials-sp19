test = {
  'name': 'q3_10',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> min_sufficient or not min_sufficient 
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
