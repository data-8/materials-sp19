test = {
  'name': 'Question 5_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Hint: If you are getting 47 as your answer, you might be computing the biggest change rather than the biggest                     decrease!
          >>> biggest_decrease == 47
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> # Hint: biggest decrease is above 30, but not 47.
          >>> 30 <= biggest_decrease < 47
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
