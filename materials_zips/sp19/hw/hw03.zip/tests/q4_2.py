test = {
  'name': 'Question 4_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> boston_under_10 >= 0 and boston_under_10 <= 100
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> manila_under_10 >= 0 and manila_under_10 <= 100
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
