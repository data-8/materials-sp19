test = {
  'name': 'Question 2_6',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> pter_over_time.take(0)
          Date       | NEI     | NEI-PTER | Year | PTER
          1994-01-01 | 10.0974 | 11.172   | 1994 | 1.0746
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
