test = {
  'name': 'q1_13',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type(question_12_choice) == list
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
