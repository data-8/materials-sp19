test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Hint 1: Try to make the word "bookkeeper"!
          >>> # 
          >>> # Hint 2: After writing this:
          >>> #   you = 'keep'
          >>> # the value of the variable named 'the' will be
          >>> #   'beekeeper'
          >>> 'beeper'.replace('p', you).replace('bee', this)[::-1]
          'repeekkoob'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
